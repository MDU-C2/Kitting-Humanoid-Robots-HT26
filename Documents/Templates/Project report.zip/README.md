# Project Report Template — DVA490 / DVA474 Project in Robotics

This repository provides the project report LaTeX template used in the courses **DVA490** and
**DVA474** at Mälardalen University.

Submit it first as the PRO2 half-time report, then extend and update it into the PRO4 final
report (rename the "Initial Results/Discussion/Conclusions" section headings once the work is
complete — see the comment at the top of `main.tex`).

For the companion project plan template (PRO1), see the separate `project-plan-template`
repository.

## Getting started

Open `main.tex` with any LaTeX editor, or upload this repository to
[Overleaf](https://www.overleaf.com/) as a new project, and replace the placeholder text with
your content.

## Writing guidance

For general academic writing advice — structuring a report, preparing figures and tables,
citation conventions, verb tenses, and working with supervisors — see *The Incomplete Guide to
Academic Writing in Robotics Research* (Adorno & Marinho), available as a course file on Canvas.
This template points to it where relevant.

## Prerequisites

Ensure you have a LaTeX distribution installed on your machine. We recommend using
[TeX Live](https://www.tug.org/texlive/) for Unix/Linux systems, [MacTeX](http://www.tug.org/mactex/)
for macOS, and [MikTeX](https://miktex.org/) for Windows. If you're using Overleaf, no local LaTeX
installation is needed since the platform is entirely web-based.

## Acknowledgments

This template is based on the Master's thesis template for Mälardalen University, created by
Emil Persson.

## License

This template is released under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0
International License (CC BY-NC-SA 4.0). This license allows you to remix, adapt, and build upon
the material in any medium or format for noncommercial purposes only, and only so long as
attribution is given to the creator. For more information, visit
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).

