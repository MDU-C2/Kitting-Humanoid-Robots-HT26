# Project Plan Template — DVA490 / DVA474 Project in Robotics

This repository provides the PRO1 project plan LaTeX template used in the courses **DVA490** and
**DVA474** at Mälardalen University.

For the companion project report template (PRO2 half-time report / PRO4 final report), see the
separate `project-report-template` repository.

## Getting started

Open `main.tex` with any LaTeX editor, or upload this repository to
[Overleaf](https://www.overleaf.com/) as a new project, and replace the placeholder text with
your content.

## Writing guidance

For general academic writing advice — structuring a text, preparing figures and tables, citation
conventions, and working with supervisors — see *The Incomplete Guide to Academic Writing in
Robotics Research* (Adorno & Marinho), available as a course file on Canvas.

## Prerequisites

Ensure you have a LaTeX distribution installed on your machine. We recommend using
[TeX Live](https://www.tug.org/texlive/) for Unix/Linux systems, [MacTeX](http://www.tug.org/mactex/)
for macOS, and [MikTeX](https://miktex.org/) for Windows. If you're using Overleaf, no local LaTeX
installation is needed since the platform is entirely web-based.

## Acknowledgments

This template is based on the Project-Plan/Project-Charter templates by Bo Tonnquist, Baseline
Management AB, with the class file created by Emil Persson.

## License

This template is released under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0
International License (CC BY-NC-SA 4.0). This license allows you to remix, adapt, and build upon
the material in any medium or format for noncommercial purposes only, and only so long as
attribution is given to the creator. For more information, visit
[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).

## Contact

For any inquiries or issues, feel free to contact us via GitHub.
